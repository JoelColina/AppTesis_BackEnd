package com.newton.security.userservice.data.repository;


import com.newton.security.userservice.data.entity.Group;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupRepository extends JpaRepository<Group, Long> {
    Group findByName(String name);

    Group findByUuid(String uuid);
}