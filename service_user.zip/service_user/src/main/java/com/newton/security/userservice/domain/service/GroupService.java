package com.newton.security.userservice.domain.service;



import com.newton.user.commons.Dto.GroupDto;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface GroupService {
    ResponseEntity<?> findByGroup(String name);
    ResponseEntity<?> findAll();
    ResponseEntity<?> save(GroupDto groupDto);
    ResponseEntity<?> update(GroupDto groupDto);
    ResponseEntity<?> delete(GroupDto groupDto);
}
