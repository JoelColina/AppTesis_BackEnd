package com.newton.security.userservice.domain.service.Impl;


import com.newton.security.userservice.data.entity.Authority;
import com.newton.security.userservice.domain.service.AuthorityService;
import com.newton.user.commons.Dto.AuthorityDto;
import com.newton.user.commons.Dto.UserDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorityServiceImpl implements AuthorityService {
    @Override
    public List<AuthorityDto> update(List<Authority> authorities, UserDto userDto) {
        return null;
    }
/*
    private LocalUserService localUserService;
     private LocalUserDto localUserDto;
     private LocalUser localUser;
     private Authority authority;
     private IUserRepository iUserRepository;
     private List<Authority> authorityList = new ArrayList<Authority>();

     private List<Authority> authorityListOld =new ArrayList<Authority>();

     private IAuthorityRepository iAuthorityRepository;

    public AuthorityServiceImpl(LocalUserService localUserService, LocalUserDto localUserDto, LocalUser localUser,
                                Authority authority, IUserRepository iUserRepository, IAuthorityRepository iAuthorityRepository) {
        this.localUserService = localUserService;
        this.localUserDto = localUserDto;
        this.localUser = localUser;
        this.authority = authority;
        this.iUserRepository=iUserRepository;
        this.iAuthorityRepository =iAuthorityRepository;
    }

    @Override
    public List<AuthorityDto> update(List<Authority> authorities, LocalUserDto localUserDto) {
        List<Authority> authorityListOld =new ArrayList<Authority>();
        localUser = iUserRepository.findByUsername(localUserDto.getUsername());
        Long id = localUser.getId();
        iAuthorityRepository.deleteAuthoritiesByUserid(id);
        if(!localUserDto.getAuthorities().isEmpty()){
            for(AuthorityDto authorityDto: localUserDto.getAuthorities()){
                iAuthorityRepository.insertAuthorityByUserId(authorityDto.getAuthority(), id);
            }
        }
        return localUserDto.getAuthorities();
    }
*/
}
