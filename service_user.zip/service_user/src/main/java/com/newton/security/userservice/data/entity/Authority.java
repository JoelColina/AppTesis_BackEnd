package com.newton.security.userservice.data.entity;

import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Repository
@Entity
@Table(name="authorities", schema = "public")
public class Authority implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column
    Long authority;
    public Long getId() {
        return id;
    }

    @Column(name="user_id")
    Long userId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Authority authority1 = (Authority) o;
        return enable == authority1.enable && id.equals(authority1.id) && authority.equals(authority1.authority) && userId.equals(authority1.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, authority, userId, enable);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuthority() {
        return authority;
    }

    public void setAuthority(Long authority) {
        this.authority = authority;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }


    boolean enable;


    private static final long serialVersionUID = -4031970414884097195L;
}
