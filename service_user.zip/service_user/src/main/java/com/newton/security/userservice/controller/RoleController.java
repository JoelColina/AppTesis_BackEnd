package com.newton.security.userservice.controller;



import com.newton.security.userservice.domain.service.RoleService;
import com.newton.security.userservice.domain.service.UtilService;
import com.newton.user.commons.Dto.RoleDto;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RefreshScope
@RestController
@RequestMapping("/api/role")
public class RoleController {

    private final RoleService roleService;
    private final UtilService utilService;

    public RoleController(RoleService roleService, UtilService utilService) {
        this.roleService = roleService;
        this.utilService = utilService;
    }

    @GetMapping("/all")
    public ResponseEntity<?> index() {
        return roleService.findAll();
    }

    @GetMapping("/{authority}")
    public ResponseEntity<?> show(@RequestParam(name = "authority") String authority) {

        return this.roleService.findByAuthority(authority);
    }


    @PostMapping()
    @Transactional
    public ResponseEntity<?> post(@Valid @RequestBody RoleDto roleDto, BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return roleService.save(roleDto);
    }

    @PutMapping("/user")
    public ResponseEntity<?> update(@Valid @RequestBody RoleDto roleDto, BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return roleService.update(roleDto);
    }

    @DeleteMapping()
    public ResponseEntity<?> delete(@Valid @RequestBody RoleDto roleDto, BindingResult result) {

        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return roleService.delete(roleDto);
    }

}
