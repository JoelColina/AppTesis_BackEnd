package com.newton.security.userservice.config.daoDinamic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class DataSourceMap {

    private static final Logger logger = LoggerFactory
            .getLogger(DataSourceMap.class);

    private final Map<Object, Object> dataSourceMap = new ConcurrentHashMap<>();

    public void addDataSource(String session, DataSource dataSource) {
        this.dataSourceMap.put(session, dataSource);
    }

    public Map<Object, Object> getDataSourceMap() {
        return dataSourceMap;
    }
}
