package com.newton.security.userservice.controller;


import com.newton.security.userservice.domain.service.UtilService;
import com.newton.user.commons.Dto.GroupDto;
import com.newton.user.commons.Dto.UserDto;
import com.newton.user.commons.Dto.PasswordUpdateDto;
import com.newton.user.commons.Dto.RoleDto;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

//@CrossOrigin(origins = "http//localhost:4200")
@RefreshScope
@RestController
@RequestMapping("/api/language")
public class LocaleController {


    private final UtilService utilService;

    public LocaleController(UtilService utilService){
        this.utilService = utilService;
    }



    @GetMapping("/locale")
    public String locale(HttpServletRequest request) {
        String ultimaUrl = request.getHeader("referer");
        return "redirect:".concat(ultimaUrl);
    }
    @GetMapping("/all")
    public List<GroupDto> index(){
        //List<Group> list =
        return  new ArrayList<>();
    }

    @GetMapping("/")
    public ResponseEntity<?> show(@RequestParam(name = "name" ) String name){
        RoleDto roleDto = new RoleDto();
        return new ResponseEntity<>(roleDto, HttpStatus.OK);
    }


    @PostMapping()
    public ResponseEntity<?> post(@Valid @RequestBody UserDto userDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return  new ResponseEntity<>( ""    ,HttpStatus.OK);
    }

    @PutMapping( )
    public ResponseEntity<?> update(@Valid @RequestBody UserDto userDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return new ResponseEntity<>( "",HttpStatus.OK);
    }

    @PutMapping("/password")
    public ResponseEntity<?> update(@Valid @RequestBody PasswordUpdateDto passwordUpdateDTO, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return new ResponseEntity<>("response", HttpStatus.OK);
    }

    @DeleteMapping()
    public ResponseEntity<?> delete(@Valid @RequestBody UserDto userDto, BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("", HttpStatus.OK);
    }





}
