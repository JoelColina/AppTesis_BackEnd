package com.newton.security.userservice.config;/*package com.newton.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories (entityManagerFactoryRef = "useEntityManagerFactory",
        transactionManagerRef = "userTransactionManager",
        basePackages = {"com.newton.security.data.base.repository"})
public class BaseConfig {
    @Autowired
    private Environment env;

    @Bean(name="baseDataSource")
    public DataSource baseDataSource(){
        DriverManagerDataSource dataSource= new DriverManagerDataSource();

        dataSource.setUrl(env.getProperty("base.datasource.url"));
        dataSource.setUsername(env.getProperty("base.datasource.username"));
        dataSource.setPassword(env.getProperty("base.datasource.password"));
        dataSource.setDriverClassName(env.getProperty("base.datasource.driverClassName"));
        return dataSource;
    }

    @Bean(name ="useEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(){
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(baseDataSource());
        em.setPackagesToScan("con.newton.security.data.base.entity");
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);

        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2dll.auto",env.getProperty("spring.jpa.hibernate.ddl-auto"));
        properties.put("hibernate.show-sql",env.getProperty("spring.jpa.show-sql"));
        properties.put("hibernate.dialct",env.getProperty("spring.jpa.database-platform"));

        return em;
    }
    @Bean(name="userTransactionManager")
    public PlatformTransactionManager transactionManager(){
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

}
__-//// clase cat quue si funciona


import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "catEntityManager", basePackages = "cl.bci.aplicaciones.cat.dao", transactionManagerRef = "catTransactionManager")

public class Cat {

	@Autowired
	private Environment env;


	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("cat.datasource.driverClassName"));
		dataSource.setUrl(env.getProperty("cat.datasource.url"));
		dataSource.setUsername(env.getProperty("cat.datasource.username"));
		dataSource.setPassword(env.getProperty("cat.datasource.password"));
		return dataSource;
	}

	@Primary
	@Bean
	public LocalContainerEntityManagerFactoryBean catEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(getDataSource());
		em.setPackagesToScan(new String[] { "cl.bci.aplicaciones.cat.to" });
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("cat.spring.jpa.hibernate.ddl-auto"));
		properties.put("hibernate.dialect", env.getProperty("cat.jpa.database-platform"));
		properties.put("hibernate.hbm2ddl.import_files",
				env.getProperty("cat.jpa.properties.hibernate.hbm2ddl.import_files"));
		em.setJpaPropertyMap(properties);
		return em;
	}

	@Primary
	@Bean
	public PlatformTransactionManager catTransactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(catEntityManager().getObject());
		return transactionManager;
	}
}




*/

