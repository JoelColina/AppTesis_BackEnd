package com.newton.security.userservice.config.daoDinamic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Component
public class DatabaseSwitchInterceptor implements HandlerInterceptor {
    @Autowired
    private CustomRoutingDataSource customRoutingDataSource;

    private static final Logger logger = LoggerFactory
            .getLogger(DatabaseSwitchInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        String hostname = request.getServerName();
        ContextHolder.setClient(hostname);
        return true;
    }
}
