package com.newton.security.userservice.domain.service;

import com.newton.security.userservice.data.entity.Authority;
import com.newton.user.commons.Dto.AuthorityDto;
import com.newton.user.commons.Dto.UserDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AuthorityService {

    List<AuthorityDto> update(List<Authority> authorities, UserDto userDto);

}
