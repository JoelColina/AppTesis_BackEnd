package com.newton.security.userservice.domain.service.Impl;


import com.newton.security.userservice.data.entity.Group;
import com.newton.security.userservice.data.repository.GroupRepository;
import com.newton.security.userservice.domain.mapper.GroupMapper;
import com.newton.security.userservice.domain.service.GroupService;
import com.newton.security.userservice.util.Constants;
import com.newton.user.commons.Dto.GroupDto;
import org.mapstruct.factory.Mappers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GroupServiceImp implements GroupService {

    private final GroupRepository repository;
    private Map<String, Object> response;
    private HttpStatus http;
    private GroupDto groupDtoNew;
    private GroupDto groupDtoOld;
    private Group groupOld;
    private  final GroupMapper mapper = Mappers.getMapper(GroupMapper.class);

    public GroupServiceImp(GroupRepository repository) {
        this.repository = repository;
    }


    @Override
    public ResponseEntity<?> findByGroup(String name) {
        response = new HashMap<>();

        if (!name.isEmpty()) {
            try {
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
                response.put(Constants.GROUP.GROUPS, mapper.groupToGroupDto(repository.findByName(name)));
                this.http = HttpStatus.ACCEPTED;
            } catch (Exception er) {
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.ERROR_DATA + er.getMessage());
                this.http = HttpStatus.BAD_REQUEST;
            }
        } else {
            response.put(Constants.GEMERAL.MESSAGE,Constants.OPERATIONS.OPERATION_NOT_OK);
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

    @Override
    public ResponseEntity<?> findAll() {
        response = new HashMap<>();

        List<GroupDto> lisDto = new ArrayList<>();
        try {
            for (Group group : this.repository.findAll()) {
                lisDto.add(mapper.groupToGroupDto(group));
            }
            response.put(Constants.GEMERAL.MESSAGE,Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.GROUP.GROUPS, lisDto);
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            response.put(Constants.GEMERAL.ERROR,  Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.ACCEPTED;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }


    @Override
    public ResponseEntity<?> save(GroupDto groupDto) {
        response = new HashMap<>();

        try {
            this.groupDtoOld = mapper.groupToGroupDto(repository.findByName(groupDto.getName()));
            if (this.groupDtoOld == null) {
                this.groupDtoNew = mapper.groupToGroupDto(repository.save(mapper.groupDtoToGroup(groupDto)));
                response.put(Constants.GEMERAL.MESSAGE,Constants.OPERATIONS.OPERATION_OK );
                response.put(Constants.GROUP.GROUP, this.groupDtoNew);
                this.http = HttpStatus.CREATED;
            } else {
                response.put(Constants.GEMERAL.MESSAGE,Constants.OPERATIONS.OPERATION_NOT_OK);
                this.http = HttpStatus.CONFLICT;
            }

        } catch (Exception er) {
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK );
            this.http = HttpStatus.BAD_REQUEST;
        }

        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }


    @Override
    public ResponseEntity<?> update(GroupDto groupDto) {
        response = new HashMap<>();
        try {
            this.groupOld = repository.findByName(groupDto.getName());
            if (this.groupOld != null) {
                Group groupNew = mapper.groupDtoToGroup(groupDto);
                groupNew.setId(this.groupOld.getId());
                this.groupDtoNew = mapper.groupToGroupDto(repository.save(groupNew));
            }
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.GROUP.GROUP, this.groupDtoNew);
            this.http = HttpStatus.ACCEPTED;

        } catch (Exception er) {
            response.put(Constants.GEMERAL.ERROR,Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.CONFLICT;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);


    }

    @Override
    public ResponseEntity<?> delete(GroupDto groupDto) {
        response = new HashMap<>();

        this.groupOld = repository.findByName(groupDto.getName());
        if (this.groupOld != null) {
            try {
                this.groupOld.setEnable(false);
                this.repository.save(this.groupOld);
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
                this.http = HttpStatus.ACCEPTED;
            } catch (Exception ex) {
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
                this.http = HttpStatus.BAD_REQUEST;
            }
        } else {
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK );
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

  private Group findByUuid(String uuid){
        return this.repository.findByUuid(uuid);
  }

}
