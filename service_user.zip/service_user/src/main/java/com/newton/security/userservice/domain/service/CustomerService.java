package com.newton.security.userservice.domain.service;


import com.newton.security.userservice.data.entity.Customer;
import com.newton.user.commons.Dto.CustomerDto;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface CustomerService {
    ResponseEntity<?> findByUsername(String username);
    ResponseEntity<?> findByName(String name);
    ResponseEntity<?> findAll();
    ResponseEntity<?> save(CustomerDto customerDto);
    ResponseEntity<?> update(CustomerDto customerDto);
    ResponseEntity<?> delete(CustomerDto customerDto);

    Customer findByUuid(String uuid);

    Customer findByDto(CustomerDto customerDto);

}
