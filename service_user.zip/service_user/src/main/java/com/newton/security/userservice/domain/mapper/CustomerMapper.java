package com.newton.security.userservice.domain.mapper;


import com.newton.security.userservice.data.entity.Customer;
import com.newton.user.commons.Dto.CustomerDto;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CustomerMapper {
    Customer customerDtoToCustomer(CustomerDto customerDto);

    CustomerDto customerToCustomerDto(Customer customer);

    default List<CustomerDto> listCustomerToListCustomerDto(List<Customer> customerList){
        if (customerList == null){
            return  new ArrayList<>();
        }
        return customerList.stream().map(this::customerToCustomerDto).collect(Collectors.toList());
    }

    default List<Customer> listCustomerDtoToListCustomer(List<CustomerDto> customerDtoList) {
        if (customerDtoList == null) {
            return new ArrayList<>();
        }
        return customerDtoList.stream().map(this::customerDtoToCustomer).collect(Collectors.toList());
    }
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    Customer updateCustomerFromCustomerDto(CustomerDto customerDto, @MappingTarget Customer customer);
}
