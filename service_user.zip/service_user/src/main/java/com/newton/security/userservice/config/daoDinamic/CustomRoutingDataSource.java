package com.newton.security.userservice.config.daoDinamic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class CustomRoutingDataSource  extends AbstractRoutingDataSource{

    private Logger logger = LoggerFactory.getLogger(CustomRoutingDataSource.class);
    @Autowired
    DataSourceMap dataSources;

    @Autowired
    private Environment env;

    @Override
    protected Object determineCurrentLookupKey() {
        //String key = ContextHolder.getClient();
          String key = "Newton";
        if (!dataSources.getDataSourceMap().containsKey(key)) {
                DriverManagerDataSource ds = new DriverManagerDataSource();
                ds.setDriverClassName(Objects.requireNonNull(env.getProperty("spring.datasource.driverClassName")));
                ds.setPassword(env.getProperty("spring.datasource.password"));
                ds.setUsername(env.getProperty("spring.datasource.username"));
                ds.setUrl(env.getProperty("spring.datasource.url") + key);
                dataSources.addDataSource(key, ds);
                setDataSources(dataSources);
                afterPropertiesSet();
        }
        return key;
    }
    @Autowired
    public void setDataSources(DataSourceMap dataSources) {
        setTargetDataSources(dataSources.getDataSourceMap());
    }





}
