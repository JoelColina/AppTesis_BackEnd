package com.newton.security.userservice.controller;



import com.newton.security.userservice.domain.service.CustomerService;
import com.newton.security.userservice.domain.service.UtilService;
import com.newton.user.commons.Dto.CustomerDto;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
@RefreshScope
@RestController
@RequestMapping("/api/customer")
public class CustomerController {


    private final CustomerService service;
    private final UtilService utilService;

    public CustomerController(CustomerService customerService, UtilService utilService){
        this.service = customerService;
        this.utilService =utilService;
    }




    @GetMapping("/all")
    public ResponseEntity<?> index(){
        return  this.service.findAll()
;    }

    @GetMapping
    public ResponseEntity<?> show(@RequestParam(name = "name" ) String name){
        return this.service.findByName(name) ;
    }


    @PostMapping()
    public ResponseEntity<?> post(@Valid @RequestBody CustomerDto customerDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result) ,HttpStatus.BAD_REQUEST );
        }
        return  this.service.save(customerDto);
    }

    @PutMapping( )
    public ResponseEntity<?> update(@Valid @RequestBody CustomerDto customerDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return this.service.update(customerDto);
    }

    @DeleteMapping()
    public ResponseEntity<?> delete(@Valid @RequestBody CustomerDto customerDto, BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return this.service.delete(customerDto);
    }
}
