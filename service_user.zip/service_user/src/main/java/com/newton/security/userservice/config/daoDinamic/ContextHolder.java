package com.newton.security.userservice.config.daoDinamic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ContextHolder {
    private static final Logger logger = LoggerFactory.getLogger(ContextHolder.class);
    private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

    public static void setClient (String  context){
        contextHolder.set(context);
    }

    public static String getClient(){
        return contextHolder.get();
    }
}
