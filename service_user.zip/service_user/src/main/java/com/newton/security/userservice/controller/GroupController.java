package com.newton.security.userservice.controller;



import com.newton.security.userservice.domain.service.GroupService;
import com.newton.security.userservice.domain.service.UtilService;
import com.newton.user.commons.Dto.GroupDto;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
@RefreshScope
@RestController
@RequestMapping("/api/group")
public class GroupController {


    private final GroupService service;
    private final UtilService utilService;

    public GroupController(GroupService service , UtilService utilService){
         this.service = service;
        this.utilService = utilService;
    }

    @GetMapping("/all")
    public ResponseEntity<?> index(){

         return  this.service.findAll();
    }

    @GetMapping("/")
    public ResponseEntity<?> show(@RequestParam(name = "name" ) String name){

          return this.service.findByGroup(name);
    }


    @PostMapping()
    public ResponseEntity<?> post(@Valid @RequestBody GroupDto groupDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return  this.service.save(groupDto);
    }

    @PutMapping( )
    public ResponseEntity<?> update(@Valid @RequestBody GroupDto groupDto, BindingResult result) {
        if (result .hasErrors()){
            return new ResponseEntity<>( this.utilService.errorResult(result),HttpStatus.BAD_REQUEST );
        }
        return  this.service.update(groupDto);
    }


    @DeleteMapping()
    public ResponseEntity<?> delete(@Valid @RequestBody GroupDto groupDto, BindingResult result) {

        if (result.hasErrors()) {
            return new ResponseEntity<>(this.utilService.errorResult(result), HttpStatus.BAD_REQUEST);
        }
        return this.service.delete(groupDto);
    }

    }
