package com.newton.security.userservice.domain.mapper;


import com.newton.security.userservice.data.entity.Role;
import com.newton.user.commons.Dto.RoleDto;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RoleMapper {
      //  RoleMapper INSTANCE = Mappers.getMapper(RoleMapper.class);


        Role roleDtoToRole(RoleDto roleDto);

        RoleDto roleToRoleDto(Role r);


        default List<RoleDto> listRoleToListRoleDto(List<Role> roleList){
                if (roleList == null){
                        return  new ArrayList<>();
                }
                return roleList.stream().map(this::roleToRoleDto).collect(Collectors.toList());
        }

        default List<Role> listRoleDtoToListRole(List<RoleDto> roleDtoList){
                if (roleDtoList == null){
                        return  new ArrayList<>();
                }
                return roleDtoList.stream().map(this::roleDtoToRole).collect(Collectors.toList());
        }


        @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
                nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
        Role updateAuthorityFromAuthorityDto(RoleDto roleDto, @MappingTarget Role role);



}
