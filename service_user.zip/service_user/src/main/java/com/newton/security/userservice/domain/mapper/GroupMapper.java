package com.newton.security.userservice.domain.mapper;


import com.newton.security.userservice.data.entity.Group;
import com.newton.user.commons.Dto.GroupDto;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface GroupMapper {
    Group groupDtoToGroup(GroupDto groupDto);
    GroupDto groupToGroupDto(Group group);

    default List<GroupDto> listGroupToListGroupDto(List<Group> groupList){
        if (groupList == null){
            return  new ArrayList<>();
        }
        return groupList.stream().map(this::groupToGroupDto).collect(Collectors.toList());
    }

    default List<Group> listGroupDtoToListGroup(List<GroupDto> groupDtoList){
        if (groupDtoList == null){
            return  new ArrayList<>();
        }
        return groupDtoList.stream().map(this::groupDtoToGroup).collect(Collectors.toList());
    }
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    Group updateCustomerFromCustomerDto(GroupDto groupDto, @MappingTarget Group group);
}
