package com.newton.security.userservice.domain.service;


import com.newton.user.commons.Dto.RoleDto;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface RoleService {

    ResponseEntity<?> findByAuthority(String Authority);
    ResponseEntity<?> findAll();
    ResponseEntity<?> save(RoleDto roleDto);
    ResponseEntity<?> update(RoleDto roleDto);
    ResponseEntity<?> delete(RoleDto roleDto);

}
