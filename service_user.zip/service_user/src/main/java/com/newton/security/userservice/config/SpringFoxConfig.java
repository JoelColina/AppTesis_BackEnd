package com.newton.security.userservice.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;


@Configuration
@EnableSwagger2
public class SpringFoxConfig {

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.newton.security.controllers"))
                .paths(PathSelectors.any())
//                .paths(PathSelectors.ant("/api/user/*"))
//                .paths(PathSelectors.ant("/api/authority/*"))
//                .paths(PathSelectors.ant("/api/customer/*"))
//                .paths(PathSelectors.ant("/api/group/"))
//                .paths(PathSelectors.ant("/api/language/*"))
                .build()
                .apiInfo(getApiInfo());
    }
    private ApiInfo getApiInfo(){
        return new ApiInfo(
                "Security  API",
                "User API Of Newton Description",
                "1.0",
                "http://newton.com/terms",
                new Contact("jhonny Cardona", "https://newton.com", "jhonny.cardona@tshgCorp.com"),
                "LICENSE",
                "LICENSE URL",
                 new ArrayList<>()
                );
    }
}