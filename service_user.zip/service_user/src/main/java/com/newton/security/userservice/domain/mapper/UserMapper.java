package com.newton.security.userservice.domain.mapper;

import com.newton.security.userservice.data.entity.User;
import com.newton.user.commons.Dto.UserDto;
import org.mapstruct.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface UserMapper {
    //    LocalUserMapper INSTANCE = Mappers.getMapper(LocalUserMapper.class);

    User userDtoToUser(UserDto userDto);


    UserDto userToUserDto(User user);

    default List<UserDto> toDtoList(List<User> localUserList) {
        if (localUserList == null) {
            return new ArrayList<>();
        }
        return localUserList.stream().map(this::userToUserDto).collect(Collectors.toList());
    }

    default List<User> toEntityList(List<UserDto> localUserDtoList) {
        if (localUserDtoList == null) {
            return new ArrayList<>();
        }
        return localUserDtoList.stream().map(this::userDtoToUser).collect(Collectors.toList());
    }


    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
            nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    User updateUserFromUserDto(UserDto userDto, @MappingTarget User user);

    User userDtoToUser1(UserDto userDto);

    UserDto userToUserDto1(User user);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    User updateUserFromUserDto1(UserDto userDto, @MappingTarget User user);
}

