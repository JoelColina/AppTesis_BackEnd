package com.newton.security.userservice.domain.mapper;



import com.newton.security.userservice.data.entity.Authority;
import com.newton.user.commons.Dto.AuthorityDto;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "spring")
public interface AuthorityMapper {
   // AuthorityMapper INSTANCE = Mappers.getMapper(AuthorityMapper.class);
   Authority authorityDtoToAuthority(AuthorityDto authorityDto);

    AuthorityDto authorityToAuthorityDto(Authority authority);

    default List<AuthorityDto> toDtoList(List<Authority> authorityList){
        if (authorityList == null){
            return  new ArrayList<>();
        }
        return authorityList.stream().map(this::authorityToAuthorityDto).collect(Collectors.toList());
    }

    default List<Authority> toEntityList(List<AuthorityDto> authorityDtoList){
        if (authorityDtoList == null){
            return  new ArrayList<>();
        }
        return authorityDtoList.stream().map(this::authorityDtoToAuthority).collect(Collectors.toList());
    }

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
            nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    Authority updateAuthorityFromAuthorityDto(AuthorityDto authorityDto, @MappingTarget Authority authority);

}
