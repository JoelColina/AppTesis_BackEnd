package com.newton.security.userservice.data.repository;


import com.newton.security.userservice.data.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

       Customer findByName(String name);


    Customer findByUuid(String uuid );

}