package com.newton.security.userservice.data.repository;


import com.newton.security.userservice.data.entity.Authority;
import org.springframework.data.jpa.repository.JpaRepository;


public interface IAuthorityRepository extends JpaRepository<Authority,Long> {

}
