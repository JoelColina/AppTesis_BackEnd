package com.newton.security.userservice.data.entity;



import lombok.*;
import org.modelmapper.internal.bytebuddy.build.HashCodeAndEqualsPlugin;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;


@Entity
@Table(name="roles" )
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column( unique = true, length = 45)
    String authority;

    @Column(length = 256)
    String Permission;


    boolean enable;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Role role = (Role) o;
        return enable == role.enable && id.equals(role.id) && authority.equals(role.authority) && Permission.equals(role.Permission);
    }

   @Override
    public int hashCode() {
        return Objects.hash(id, authority, Permission, enable);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    public String getPermission() {
        return Permission;
    }

    public void setPermission(String permission) {
        Permission = permission;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    private static final long serialVersionUID = 6168489106502885232L;
}