package com.newton.security.userservice.data.entity;

import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Repository
@Entity
@Table(name = "customer", schema = "public")
public class Customer implements Serializable {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Long Id;

        @Column(length = 60)
        String name;

        @Column(name = "uuid")
        String uuid;

        @Column(length = 250)
        String denomination;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name="group_id" , nullable = true)
        Group groupId;

        @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
        @JoinColumn(name = "customer_id")
        private Set<User> users = new HashSet<>();


        String address1;

        String address2;

        String state;

        String country;

        String region;

        @Column(name = "urllogo")
        String urlLogo;

        @Column(name = "logo")
        byte[] logo;

        boolean enable;
        public Long getId() {
                return Id;
        }

        public void setId(Long id) {
                Id = id;
        }

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }

        public String getUuid() {
                return uuid;
        }

        public void setUuid(String uuid) {
                this.uuid = uuid;
        }

        public String getDenomination() {
                return denomination;
        }

        public void setDenomination(String denomination) {
                this.denomination = denomination;
        }

        public Group getGroupId() {
                return groupId;
        }

        public void setGroupId(Group groupId) {
                this.groupId = groupId;
        }

        public boolean isEnable() {
                return enable;
        }

        public void setEnable(boolean enable) {
                this.enable = enable;
        }

        public String getAddress1() {
                return address1;
        }

        public void setAddress1(String address1) {
                this.address1 = address1;
        }

        public String getAddress2() {
                return address2;
        }

        public void setAddress2(String address2) {
                this.address2 = address2;
        }

        public String getState() {
                return state;
        }

        public void setState(String state) {
                this.state = state;
        }

        public String getCountry() {
                return country;
        }

        public void setCountry(String country) {
                this.country = country;
        }

        public String getRegion() {
                return region;
        }

        public void setRegion(String region) {
                this.region = region;
        }

        public String getUrlLogo() {
                return urlLogo;
        }

        public void setUrlLogo(String urlLogo) {
                this.urlLogo = urlLogo;
        }

        public byte[] getLogo() {
                return logo;
        }

        public void setLogo(byte[] logo) {
                this.logo = logo;
        }

        private static final long serialVersionUID = -2676493452051270746L;
}
