package com.newton.security.userservice.data.repository;


import com.newton.security.userservice.data.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RolesRepository extends JpaRepository<Role, Long>, JpaSpecificationExecutor<Role> {
   Role findByAuthority(String name );


}