package com.newton.security.userservice.domain.service.Impl;


import com.newton.security.userservice.data.entity.Role;
import com.newton.security.userservice.data.repository.RolesRepository;
import com.newton.security.userservice.domain.mapper.RoleMapper;
import com.newton.security.userservice.domain.service.RoleService;
import com.newton.security.userservice.util.Constants;
import com.newton.user.commons.Dto.RoleDto;
import org.mapstruct.factory.Mappers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class RoleServiceImpl implements RoleService {
    private final RolesRepository rolesRepository;
    private Map<String, Object> response;

    private final RoleMapper mapper = Mappers.getMapper(RoleMapper.class);
    private RoleDto roleDtoNew;
    private RoleDto roleDtoOld;
    private Role role;

    private HttpStatus http;

    public RoleServiceImpl(RolesRepository rolesRepository) {
        this.rolesRepository = rolesRepository;

    }

    @Override
    public ResponseEntity<?> findByAuthority(String authority) {
        response = new HashMap<>();
        try {
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.ROLE.AUTHORITY, this.mapper.roleToRoleDto(this.rolesRepository.findByAuthority(authority)));
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(response, this.http);
    }

    @Override
    public ResponseEntity<?> findAll() {
        List<RoleDto> listDto = new ArrayList<>();
        response = new HashMap<>();
        try {
            for (Role role : this.rolesRepository.findAll()) {
                listDto.add(this.mapper.roleToRoleDto(role));
            }
            listDto .sort(Comparator.comparing(RoleDto::getAuthority));
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.ROLE.AUTHORITIES, listDto);
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(response, this.http);

    }



    @Override
    @Transactional
    public ResponseEntity<?> save(RoleDto roleDto) {
        this.roleDtoOld = new RoleDto();
        this.roleDtoNew = new RoleDto();
        this.response = new HashMap<>();
        try {

            this.role = this.mapper.roleDtoToRole(roleDto);
            this.roleDtoNew = this.mapper.roleToRoleDto(rolesRepository.findByAuthority(this.role.getAuthority()));
            if (this.roleDtoNew == null) {
                this.roleDtoNew = this.mapper.roleToRoleDto(rolesRepository.save(this.role));
            }
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(this.response, this.http);
    }

    @Override
    public ResponseEntity<?> update(RoleDto roleDto) {
        this.response = new HashMap<>();
        try {
            this.roleDtoOld = this.mapper.roleToRoleDto(rolesRepository.findByAuthority(roleDto.getAuthority()));
            this.roleDtoNew = this.mapper.roleToRoleDto(rolesRepository.save(this.mapper.roleDtoToRole(this.roleDtoOld)));
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            this.response.put(Constants.ROLE.AUTHORITY, this.roleDtoNew);
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(this.response, this.http);
    }

    @Override
    public ResponseEntity<?> delete(RoleDto roleDto) {
        this.response = new HashMap<>();

        try {
            this.role = rolesRepository.findByAuthority(roleDto.getAuthority());
            this.role.setEnable(false);
            this.mapper.roleToRoleDto(rolesRepository.save(this.role));
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception er) {
            this.response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_NOT_OK + er.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(this.response, this.http);
    }

}
