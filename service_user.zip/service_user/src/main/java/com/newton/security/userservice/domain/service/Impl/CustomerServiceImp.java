package com.newton.security.userservice.domain.service.Impl;


import com.newton.security.userservice.data.entity.Customer;
import com.newton.security.userservice.data.repository.CustomerRepository;
import com.newton.security.userservice.domain.mapper.CustomerMapper;
import com.newton.security.userservice.domain.service.CustomerService;
import com.newton.security.userservice.util.Constants;
import com.newton.user.commons.Dto.CustomerDto;
import org.mapstruct.factory.Mappers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CustomerServiceImp implements CustomerService {

    private final CustomerRepository repository;
    private HttpStatus http;
    private Map<String, Object> response;
    private CustomerDto customerDtoNew;
    private CustomerDto customerDtoOld;
    private Customer customerOld;
    private final CustomerMapper mapper = Mappers.getMapper(CustomerMapper.class);

    public CustomerServiceImp(CustomerRepository repository) {

        this.repository = repository;
    }


    @Override
    public ResponseEntity<?> findByUsername(String name) {
        if (!name.isEmpty()) {
            try {
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
                response.put(Constants.CUSTOMER.CUSTOMER, mapper.customerToCustomerDto(this.repository.findByName(name)));
                this.http = HttpStatus.ACCEPTED;
            } catch (Exception ex) {
                response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
                this.http = HttpStatus.BAD_REQUEST;
            }
        } else {
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK  );
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);


    }

    @Override
    public ResponseEntity<?> findByName(String name) {
        response  = new HashMap<>();
        try{
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.CUSTOMER.CUSTOMER, mapper.customerToCustomerDto(this.repository.findByName(name)));
            this.http = HttpStatus.ACCEPTED;

        }catch (Exception ex){
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
            this.http = HttpStatus.CONFLICT;
        }
           return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

    @Override
    public ResponseEntity<?> findAll() {
        response = new HashMap<>();

        List<CustomerDto> listDto = new ArrayList<>();

        try {
            for (Customer customer : this.repository.findAll()) {
                listDto.add(mapper.customerToCustomerDto(customer));
            }
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.CUSTOMER.CUSTOMERS , listDto);
            this.http = HttpStatus.ACCEPTED;

        } catch (Exception ex) {
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
            this.http = HttpStatus.CONFLICT;
        }

        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }


    @Override
    public ResponseEntity<?> save(CustomerDto customerDto) {
        response = new HashMap<>();
        try {
            this.customerOld = this.repository.findByName(customerDto.getName());
            if (this.customerOld == null || !(this.customerOld.equals(this.mapper.customerDtoToCustomer(customerDto)))) {
                response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
                response.put(Constants.CUSTOMER.CUSTOMER, mapper.customerToCustomerDto(this.repository.save(mapper.customerDtoToCustomer(customerDto))));
                this.http = HttpStatus.CREATED;
            } else {
                response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK );
                this.http = HttpStatus.CONFLICT;
            }
        } catch (Exception ex) {
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

    @Override
    public ResponseEntity<?> update(CustomerDto customerDto) {
        response = new HashMap<>();

        try {
            this.customerOld = this.repository.findByName(customerDto.getName());
            Customer customerNew = mapper.customerDtoToCustomer(customerDto);
            customerNew.setId(this.customerOld.getId());
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.CUSTOMER.CUSTOMER, mapper.customerToCustomerDto(this.repository.save(customerNew)));
            this.http = HttpStatus.ACCEPTED;
        } catch (Exception ex) {
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

    @Override
    public ResponseEntity<?> delete(CustomerDto customerDto) {
        try {
            this.customerOld = this.repository.findByName(customerDto.getName());
            this.customerOld.setEnable(false);
            response.put(Constants.GEMERAL.MESSAGE, Constants.OPERATIONS.OPERATION_OK);
            response.put(Constants.CUSTOMER.CUSTOMER, mapper.customerToCustomerDto(this.repository.save(this.customerOld)));
            this.http = HttpStatus.ACCEPTED;
        }catch (Exception ex){
            response.put(Constants.GEMERAL.ERROR, Constants.OPERATIONS.OPERATION_NOT_OK + ex.getMessage());
            this.http = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Map<String, Object>>(response, this.http);
    }

    @Override
    public Customer findByUuid(String uuid) {
        return this.repository.findByUuid( uuid);
    }


    @Override
    public Customer findByDto(CustomerDto customerDto) {
         return mapper.customerDtoToCustomer(customerDto);
    }
}
